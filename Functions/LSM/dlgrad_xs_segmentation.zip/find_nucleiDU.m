function [dorsal,nuc,xnuc,ynuc,snuc,std_dl,std_nuc,U,bw1,u] = ...
	find_nucleiDU(data,I,xp,yp,varargin)
%Finds nuclei in embryo cross sections.
%
%function nucmask = find_nucleiDU(data,t,theta,r_center,h_nuc,varargin)
%
%
% This function takes an image of the nuclei (stored in the second color
% channel of "I"), and unrolls it to find the location of the nuclei.
% These locations are mapped back onto the original location at the
% periphery of the non-unrolled embryo image.  The nuclei are segmented
% that way.  Then we calculate the Dorsal intensity (stored in "dorsal"),
% and the nuclear intensity (stored in "nuc") as well as the locations of
% the nuclei, "xnuc" and "ynuc".  The variable "snuc" corresponds to the
% pseudo-arc length location of the nuclei around the periphery of the
% embryo.
%
%
% Optional argument varargin can consist of these things, in this order:
%	* "Yhatmax": number of pixels into the embryo we take our data from.
%		When we unroll the embryo, we are essentially throwing out all data
%		except a thin annulus.  Yhatmax is the width of that annulus.
%		If this is not specified, but you still want to specify other
%		arguments, put empty brackets -- [] -- in place of this argument.
%	* "yesplot": whether you want to plot the outcome.  Default, "false".  
%		If this is not specified, but you still want to specify other 
%		arguments, put empty brackets -- [] -- in place of this argument.

%
% Unpacking varargin.
%
nArg = size(varargin,2); iArg = 1; 
if nArg >= iArg && ~isempty(varargin{iArg})
	Yhatmax = varargin{iArg}; else
	Yhatmax = round(18.36/data.scalings(1));
end, iArg = iArg + 1;
if nArg >= iArg && ~isempty(varargin{iArg})
	yesplot = varargin{iArg}; else
	yesplot = false;
end%, iArg = iArg + 1;

I0 = I; % original image
I = I(:,:,2); % the histones
[H,W] = size(I);
nt = length(xp) - 1;
xc = round(W/2); yc = round(H/2);
x = (1:W); y = (1:H)';

%
% Background subtract and smooth out gaussian noise
%
I = imtophat(I,strel('disk',20));
I = gaussFiltDU(I);

%
% Unrolling
%
U = unroll2(I,xp,yp,Yhatmax); % unrolled strip of nuc layer
[h,w] = size(U);


%
% radius of nuclei
%
nucrad = 1.5/data.scalings(1);
N = round(nucrad);
se = strel('disk',N);
se1 = strel('line',round(2*N+1),90);

%
% Segmenting the unrolled image
%
U2 = [U(:,end-(2*N-1):end),U,U(:,1:2*N)]; % padding image w periodic bc's
[y1,y2,nuc1] = reregister(U,0.5); % taking only the nuclei in PD axis
nuc2 = [nuc1(end-(2*N-1):end);nuc1;nuc1(1:2*N)]; % padding again.

%
% Segmentation using watershed.  This gives us definitive breaks between
% the nuclei.
%
Io1 = imopen(nuc2,se1);
bwc1 = ~watershed(Io1);
bw1 = ~watershed(imcomplement(Io1));

t = find(bw1); % trough locations -- breaks b/w nuclei
p = find(bwc1); % peak locations -- "centers" of nuclei

%
% Using the locations of "troughs" and "peaks", we perform a hard
% thresholding segmentation locally.  We only focus on the area of the
% image where a _single_ nucleus is and segment there.  We only take the
% top 75% intensity pixels.
%
if p(1) < t(1), t = [1;t]; end
if p(end) > t(end), t(end+1) = size(U2,2); end
wp = length(p);
bw1 = false(size(U2));
for k = 1:wp % hard threshold segmentation between two troughs
	u = U2(:,t(k)+1:t(k+1)-1);
	Y = prctile(u(:),75);
	bw1(:,t(k)+1:t(k+1)-1) = u > Y;
end
bw1 = imopen(bw1,se); % cleaning up weird edges of the segmented image.  
% This is so that, if the "nucleus" has weird arms or appendages, we remove
% those with the morphological opening.

%
% Getting "x" and "y" values for the (1) centroids and (2) pixel list of
% all the nuclei in the unrolled strip.  Later, these will be used to
% recontruct the segmented image in the original, non-unrolled coordinate
% system.
%
stats1 = regionprops(bw1,'Centroid','PixelList');
bw1 = bw1(:,2*N+1:end-2*N);
centroids = cat(1,stats1(:).Centroid);
xcen = centroids(:,1); ycen = centroids(:,2);
xcen = xcen - 2*N;
v = xcen > w | xcen < 1;
stats1(v) = [];
xcen(v) = []; snuc = xcen;
ycen(v) = [];

n_nuc = length(stats1);

if yesplot && ispc
	figure
	u = cat(3,double(bw1),mDU(double(U)),double(bw1));
	imshow(u)
end

%
% Now we transform the centroid coordinates from theta,Yhat coordinates to
% original (non-unrolled) image x,y coordinates.
%
xpround = roundx(xp,x); % "roundx" is a helper function.
ypround = roundx(yp,y);
ds = round(sqrt(diff(xpround).^2 + diff(ypround).^2));
% ds = sqrt(diff(xp).^2 + diff(yp).^2);
s = [0;cumsum(ds)]; % pseudo arclength.
[th,r] = cart2pol(xp-xc,yp-yc);

theta = linspace(-pi,pi,nt+1);
th_center = interp1(s,theta,xcen);

r0 = interp1(linspace(-pi,pi,nt+1),r,th_center);
r_center = -ycen*Yhatmax/h + r0;

xnuc = r_center.*cos(th_center) + xc; % centroids in non-unrolled
ynuc = r_center.*sin(th_center) + yc; % (i.e., original) image coordinates.

%
% Now we do the same transformation, but on each individual pixel from the
% segmented nuclei.
%
L = zeros(size(I));
for i = 1:n_nuc
	px = stats1(i).PixelList;
	xlist = px(:,1); ylist = px(:,2); % PixelList gives x first, then y.
	xlist = xlist - 2*N; % fixing the offset
	xlist = mod(xlist,w);
	thlist = interp1(s,theta,xlist);
	r0 = interp1(linspace(-pi,pi,nt+1),r,thlist);
	rlist = -ylist*Yhatmax/h + r0;
	
	x2D = round(rlist.*cos(thlist) + xc);
	y2D = round(rlist.*sin(thlist) + yc);
	idx = (x2D-1)*H + y2D;
	
	L(idx) = i;
end
L = imfill(L,'holes'); % filling in holes
L = imopen(L,se); % cleaning up weird edges of nuclei, again
stats2 = regionprops(L,'PixelIdxList');
% Note that here, "L" is not a bw image, but is a "double" array.  This is
% because each nucleus is represented by a distinct integer.  This is
% important because, after transforming back to the original coordinates,
% and filling in the "holes" that may have appeared as the result of the
% "rerolling", some of the distinctly-segmented nuclei may then touch.
% They can still be distinguished because they have different integer
% labels.

%
% Plotting, if asked for
%
u = cat(3,~~L,mDU(I),~~L); % "u" is a diagnostic tool.
if yesplot && ispc
	figure
	imshow(u,[])
end

%
% Now that we have the nuclei fully-segmented in the 2D periphery, let's
% calculate dorsal and nuclear levels.
%
I_dorsal = I0(:,:,1);
I_nuc = I0(:,:,2);
dorsal = zeros(n_nuc,1); nuc = dorsal;
std_dl = dorsal; std_nuc = dorsal;
for i = 1:length(stats2)
	v = stats2(i).PixelIdxList;
	
	Y = double(I_dorsal(v));
	dorsal(i) = mean(Y);
	std_dl(i) = std(Y)/sqrt(length(Y));
	
	Y = double(I_nuc(v));
	nuc(i) = mean(Y);
	std_nuc(i) = std(Y)/sqrt(length(Y));
	
% 	Y = prctile(double(I_dorsal(v)),[25 50 75]);
% 	dorsal(i) = Y(2);
% 	std_dl(i) = 0.5*(Y(3) - Y(1));
	
% 	Y = prctile(double(I_nuc(v)),[25 50 75]);
% 	nuc(i) = Y(2);
% 	std_nuc(i) = 0.5*(Y(3) - Y(1));
end

%
% Removing "nuclei" that had eroded away from the morph opening
%
v = isnan(dorsal) | isnan(nuc) | dorsal == 0 | nuc == 0;
dorsal(v) = []; nuc(v) = []; xnuc(v) = []; ynuc(v) = []; snuc(v) = [];
std_dl(v) = []; std_nuc(v) = [];

%
% Nuclei whose intensity is 2 IQR's from the median will be considered
% spurious and be cast off.
%
Y = prctile(nuc,[25 50 75]);
v = nuc < Y(2)-2*(Y(3)-Y(1));
dorsal(v) = []; nuc(v) = []; xnuc(v) = []; ynuc(v) = []; snuc(v) = [];
std_dl(v) = []; std_nuc(v) = [];



