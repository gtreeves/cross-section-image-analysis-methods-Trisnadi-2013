function [xp,yp] = borderFinder(I,varargin)
%Finds the border that surrounds the cross-sectioned embryo.
%
%function [xp,yp] = borderFinder(I,varargin)
%
% This function takes an image of am embryo cross-section and fits an
% ellipse to the outer edge of the embryo.  First, the image is median
% filtered.  Then, taking 15 degree slices of the image (like a pizza),
% average intensity of the pixels within the slice is found as a function
% of distance from the center of the image.  The radius where the intensity
% drops to 25% maximal is where we say the edge of the embryo is.  Then,
% these points are connected and everything inside is considered to be a
% solid object (whcih should cover the embryo almost perfectly).  The best-
% ellipse representation of this solid object is then computed and returned
% in "s".
%
% "I": can be either a uint8 grayscale image, or string of filename.
%
% Optional argument varargin can consist of these things, in this order:
%	(1) "h": height of intensity cutoff.  Default, 0.25.
%		If this is not specified, but you still want to specify other 
%		arguments, put empty brackets -- [] -- in place of this argument.
%	(2) "yesplot": whether or not to plot the image and the boundary.
%		Default, false.
%		If this is not specified, but you still want to specify other 
%		arguments, put empty brackets -- [] -- in place of this argument.
%	(3) "nt": choice for number of bins in theta.  Will determine length of
%		outputs "xp" and "yp" (which will be nt+1).  Default, 60.
% 
%
% "xp,yp": the points along the perimeter of the embryo.


warning off MATLAB:divideByZero

%
% Unpacking varargin.
%
nArg = size(varargin,2); iArg = 1; 
if nArg >= iArg && ~isempty(varargin{iArg})
	h = varargin{iArg}; else 
	h = 0.25;
end, iArg = iArg + 1;
if nArg >= iArg && ~isempty(varargin{iArg})
	yesplot = varargin{iArg}; else 
	yesplot = false;
end, iArg = iArg + 1;
if nArg >= iArg && ~isempty(varargin{iArg})
	nt = varargin{iArg}; else
	nt = 60;
end%, iArg = iArg + 1;

%
% Reading in "I"
%
if ischar(I)
	I = imread(I);
end
o = size(I,3);
if o > 1
	I = sum(double(I),3);
end

%
% First we must extract our region of interest.  There will be a rectangle
% that contains the embryo, outside of which all pixels will be zero.
%
maxbw = logical(max(I)); j = find(maxbw); j1 = j(1); j2 = j(end); % cols w/
% left- and right- most nonzero pixels
bwj = logical(I(:,j1)); i = find(bwj); i1 = i(1); i2 = i(end); % rows w/
% upper- & lower- most nonzero pixels from column j1 & j2.  Since we are
% looking for a rectangle, the pts (i1,j1) & (i2,j2) should be the upper-
% left and lower-right corners, respectively.  We now delete everything
% outside of this.
I = I(i1:i2,j1:j2);
[m,n] = size(I);

%
% Gaussian filter, w/std 2.
%
sig = 3;
I = gaussFiltDU(I,sig);
I = imtophat(I,strel('disk',25));

%
%  Now we divide the image into small regions in polar coordinates.
%
xc = round(n/2); yc = round(m/2);
x = (1:n) - xc;  y = (1:m)' - yc;
X = repmat(x,m,1); Y = repmat(y,1,n);

[Theta,R] = cart2pol(X,Y);
clear X Y

% nr = 100; % number of bins in r.  "nt", the bins in theta, in varargin.
r_out = zeros(nt,1);
theta = linspace(-pi,pi,nt+1)';
% r = linspace(0,max(xc,yc),nr)';

%
% Here we loop through each "pizza-slice" of theta.  In each slice, we try
% to predict the location of the edge of the embryo.
%
for i = 1:nt

	%
	% I1 is a column vector of image intensity values that lie within our
	% current slice.  The col vec r1 coresponds to the radii of these
	% intensity values.  Then, we sort these vectors together such that the
	% values of r1 are ascending, and smooth.
	%
	I1 = I(Theta > theta(i) & Theta < theta(i+1));
	r0 = R(Theta > theta(i) & Theta < theta(i+1));

	[r0,ir0] = sort(r0);
	r0 = round(r0);
	r = (r0(1):r0(end))'; nr = length(r);
	I1 = I1(ir0);
	npt = length(I1); % number of points for raw data.
	n0 = floor(npt/nr); % properties of npt/nt.  This helps us determine the 
	% shape and locations of "ones" in the matrix "M", which is the linear
	% transform from a string of individual pixel intensity values to those
	% averaged into bins. 
	
	rowind = r0 - r0(1) + 1;
	colind = (1:npt)';
	M = sparse(rowind,colind,1,nr,npt); sumM = sum(M,2);
	Y0 = (M*double(I1))./sumM;
	Y0(isnan(Y0)) = 0;
	Y1 = imtophat(Y0,strel('line',100,90));
% 	Y1 = smooth(double(I1),n0);
	
	%
	% Transforming the data to get between zero and one.  Then, we throw
	% out the background (that is, intensities that are below 0.05).
	%
	Y1min = min(Y1);
	Y1max = max(Y1);
	y1 = (Y1 - Y1min)/(Y1max - Y1min); % normalized intensity
	
	isig = find(y1 > 0.05); % location of signal.
	ibkgrnd = isig(end); r_end = r(ibkgrnd);	
	
	%
	% Now we have an upper limit to the "r" of the embryo, r_end.  We
	% assume the edge of the embryo is in the interval (r_end/3,r_end).
	%
	[iY1,iY1] = roundx(r_end/3,r); % location of smallest r.
	[maxY,iY2] = max(Y1(iY1:ibkgrnd)); iY2 = iY2 + (iY1 - 1);
	Y2 = Y1(iY2:ibkgrnd);
	
	%
	% Normalizing the intensities again, this time only taking the chunk
	% that we care about.
	%
	Y2min = Y1min;
	Y2max = max(Y2);
	y2 = (Y2 - Y2min)/(Y2max - Y2min); % normalized intensity #2
	i_out = find(y2(1:end-1) >= h & y2(2:end) < h);
	if ~isempty(i_out)
		i_out = i_out(end);
	else
		i_out = length(y2);
	end

	r_out(i) = r(iY2-1+i_out); % the radius of the edge of the embryo.

	%
	% Plotting.
	%
% 	if i > 26 && i < 38
% 		figure(i)
% 		plot(r,Y1,r_out(i),h*(Y2max - Y2min)+Y2min,'o')
% 	end
end

%
% Trying to discard outliers.  Who knows if this'll work or not.  It should
% work for single outliers.  I don't think it would work for mulitple
% outliers, or outlier regions.
%
dtheta = theta(2) - theta(1);
rtt = zeros(size(r_out));
for k = 2:length(r_out)-1
	rtt(k) = (r_out(k-1) - 2*r_out(k) + r_out(k+1))/dtheta^2; 
end
rtt(1) = (r_out(end) - 2*r_out(1) + r_out(2))/dtheta^2;
rtt(end) = (r_out(end-1) - 2*r_out(end) + r_out(1))/dtheta^2;

Y = prctile(rtt,[25 50 75]);
k = find(abs(rtt) > abs(3*(Y(3)-Y(1)) - Y(2)));

if length(k) == 3 && k(2)-k(1) == 1 && k(3)-k(2) == 1
	theta2 = theta(1:end-1);
	theta2(k(2)) = [];
	r_out2 = r_out;
	r_out2(k(2)) = [];
	r_out(k(2)) = spline(theta2,r_out2,theta(k(2)));
end

%
% The points we predict are on the outside of the embryo.
%
dr = 0; % an arbitrary offset.
xp = (r_out([1:end,1])-dr).*cos(theta) + xc; % I used to round these.
yp = (r_out([1:end,1])-dr).*sin(theta) + yc;

%
% Plotting, if you want.
%
if yesplot && ispc
	c1628(I)
	hold on
	plot(xp,yp,'r o -')
end


