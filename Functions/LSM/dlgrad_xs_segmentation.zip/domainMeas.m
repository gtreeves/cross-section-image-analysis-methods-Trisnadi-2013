function [t,s,perim,x,y] = domainMeas(I,xp,yp,varargin)
%Finds domains of gene expression in a cross-sectioned embryo.
%
%function [t,s,perim,x,y] = domainMeas(I,xp,yp,varargin)
%
% This function takes a truecolor cross-sectional image of an embryo and
% finds the fluorescence intensity (gene expression) as a function of
% fractions of total circumference.  This function can find several
% different domains of gene expression if multiple, non-overlapping genes 
% are in the same color channel.
%
% "I": can be either a uint8/uint16 grayscale image, or string of filename
% "p": params of the ellipse that best-fit the embryo image given in "I".
%	(Output of "ellipseFinder.m".)
% 
% Optional argument varargin can consist of the following things:
%	(1) "rbr": Rolling ball radius (sort of) when subtracting background
%		from the intensity vs theta plot. Should be a vector of length n_c,
%		where n_c is the number of color channels.  It is good to give a
%		guess for the largest domain percent size.  For example, if you're
%		measuring a color channel with two genes, one which is expected to
%		take up ~7% (like zen), & the other ~20% (like sna), then put 0.2
%		for rbr. Default, [0.5 0.2 0.3].
%		If this is not specified, but you still want to specify other
%		arguments, put empty brackets -- [] -- in place of this argument.
%	(2) "makeavi": an option that will make a movie of the analysis
%		process if "true".  Default, "false".
%
% "t": npts-by-nChannels array of smoothened and background-subtracted
%	fluorescent intensities.
% "smth": same as "t" but the smoothed, not bkgrnd subtracted, data.
% "raw": same as "t" and "smth", but the raw data.
% "s": arclength, going from -1 to +1, with "npts" points.
% 


%
% Unpacking varargin.
%
nArg = size(varargin,2); iArg = 1;
if nArg >= iArg && ~isempty(varargin{iArg})
	rbr = varargin{iArg}; else
	rbr = [0.5 0.2 0.3];
end, iArg = iArg + 1;
if nArg >= iArg && ~isempty(varargin{iArg})
	makeavi = varargin{iArg}; else
	makeavi = false;
end
% end, iArg = iArg + 1;

Yhatmax = 30;

%
% Reading in "I"
%
if ischar(I)
	I = imread(I);
end
% I0 = I;

o = size(I,3);
if o > 1
	I1 = sum(double(I),3);
else
	I1 = double(I);
end

%
% First we must extract our region of interest.  There will be a rectangle
% that contains the embryo, outside of which all pixels will be zero.
%
maxbw = logical(max(I1)); j = find(maxbw); j1 = j(1); j2 = j(end); % cols w
% left- and right- most nonzero pixels
bwj = logical(I1(:,j1)); i = find(bwj); i1 = i(1); i2 = i(end); % rows w/
% upper- & lower- most nonzero pixels from column j1 & j2.  Since we are
% looking for a rectangle, the pts (i1,j1) & (i2,j2) should be the upper-
% left and lower-right corners, respectively.  We now delete everything
% outside of this.
I = I(i1:i2,j1:j2,:);
[m,n,o] = size(I);

%
% Gaussian filter, w/std 2.
%
sig = 2; nn = -6:6; % when sigma is 2, then 6 flanking pixels is suff.
se = normpdf(nn,0,sig); % you always have mean zero for this.
% I = conv2(I,se,'same');
% I = conv2(I,se','same');
I = imfilter(I,se,'replicate','same','conv');
I = imfilter(I,se','replicate','same','conv');

%
% Perimeter of the embryo
%
dxp = diff(xp); dyp = diff(yp); ds = sqrt(dxp.^2 + dyp.^2); 
perim = sum(ds); 

%
% Increasing the density of points around the embryo
%
ns = 300; % Number of pts around the outside of the bro we will use.
S = perim/ns*ones(ns,1); S = [0;cumsum(S)]; % global pseudo arclength

x = zeros(ns+1,1); y = zeros(ns+1,1);
x(1) = xp(1); y(1) = yp(1);
Sr = 0; % running total of pseudoarclength.
i = 1;
for j = 1:ns-1
	D = S(j+1) - Sr;
	D2 = D + sqrt((x(j)-xp(i))^2 + (y(j)-yp(i))^2);
	if D2 >= ds(i) && i < length(ds)
		D2 = D - sqrt((xp(i+1)-x(j))^2 + (yp(i+1)-y(j))^2);
		i = i + 1;
	end
	d = D2/ds(i);
	x(j+1) = d*dxp(i) + xp(i);
	y(j+1) = d*dyp(i) + yp(i);
	
	Sr = Sr + sqrt((x(j+1) - x(j))^2 + (y(j+1) - y(j))^2);	
end
x(end) = x(1); y(end) = y(1);
dx = diff(x); dy = diff(y); ds = sqrt(dx.^2 + dy.^2); 
perim2 = sum(ds); ss = 2*[0;cumsum(ds)]/perim2 - 1;

%
% Defining image coordinates
%
x_im = (1:n); y_im = (1:m)';
X = repmat(x_im,m,1); Y = repmat(y_im,1,n);

%
% Building the raw data
%
raw = zeros(ns,o);

for i = 1:ns
	
	%
	% Defining window that we care about (don't want to do all these
	% calculations on the whole image...what a waste of time that would be!
	%
	[jx,jx] = roundx(x(i),x_im);
	[iy,iy] = roundx(y(i),y_im);
	
	j1 = max(jx-50,1);
	j2 = min(jx+50,n);
	i1 = max(iy-50,1);
	i2 = min(iy+50,m);
	
	%
	% Transforming coordinates on our little local rectangle.
	%
	theta = atan2(y(i+1)-y(i),x(i+1)-x(i));
	Xhat = (X(i1:i2,j1:j2) - x(i))*cos(theta) + ...
		(Y(i1:i2,j1:j2) - y(i))*sin(theta);
	Yhat = -(X(i1:i2,j1:j2) - x(i))*sin(theta) + ...
		(Y(i1:i2,j1:j2) - y(i))*cos(theta);
	
	xhat = (x(i+1) - x(i))*cos(theta) + ...
		(y(i+1) - y(i))*sin(theta); % xhat should be ~ds.
% 	yhat = -(x(i+1) - x(i))*sin(theta) + ...
% 		(y(i+1) - y(i))*cos(theta); % yhat should be zero.
	
	%
	% Finding the trapezoidal region that we will include in our
	% measurement of the raw data at this point s(i).  To do this, we need
	% to approximate the normals to our points (0,0) and (xhat,yhat).
	%
	if i == 1
		x0 = x(ns); y0 = y(ns);
	else
		x0 = x(i-1); y0 = y(i-1);
	end
	if i == ns
		x2 = x(2); y2 = y(2);
	else
		x2 = x(i+2); y2 = y(i+2);
	end
	xhat0 = (x0 - x(i))*cos(theta) + (y0 - y(i))*sin(theta);
	yhat0 = -(x0 - x(i))*sin(theta) + (y0 - y(i))*cos(theta);
	xhat2 = (x2 - x(i))*cos(theta) + (y2 - y(i))*sin(theta);
	yhat2 = -(x2 - x(i))*sin(theta) + (y2 - y(i))*cos(theta);
	
% 	Yhat = -Yhat; yhat = -yhat; yhat0 = -yhat0; yhat2 = -yhat2;
	
	m1 = -yhat0/(xhat - xhat0);
	m2 = yhat2/xhat2;	
	
	u = Yhat < Yhatmax & Yhat >= 0;
	v = Xhat > -m1*Yhat & Xhat < -m2*Yhat + xhat;
	bw = u & v;
	
	for j = 1:o
		I1 = I(i1:i2,j1:j2,j);
		I1 = I1(bw);
		raw(i,j) = mean(I1(:));
	end

end

raw = raw([1:end,1],:);

s = linspace(-1,1,ns+1)';
t = interp1(ss,raw,s);











