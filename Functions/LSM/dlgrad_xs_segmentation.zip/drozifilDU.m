function data = drozifilDU(varargin)
%Finds the positions of nuclei and their concentration of dorsal.
%
%function data = drozifilDU(varargin)
%
% Detects nuclei in a 3D stack of images of embryo cross sections.
%
% The function returns the structure 'data' with the fields: Area,
% Centroid,PixelList,PixelIdxList, as they are defined in the description
% of the 'regionprops' function.
%
% Optional argument varargin can consist of these things, in this order:
%	* "lsmfile": string containing the name of the lsm file that we are
%		analyzing, including path to that file (ex: 'Images/NUC12A.lsm').
%		Default, empty strings ''.
%		If this is not specified, but you still want to specify other
%		arguments, put empty brackets -- [] -- in place of this argument.
%	* "nt": choice for number of bins in theta.  Will determine length of
%		outputs "xp" and "yp" (which will be nt+1).  Default, 60.
%		If this is not specified, but you still want to specify other
%		arguments, put empty brackets -- [] -- in place of this argument.
%	* "yesplot":
%

%
% Unpacking varargin.
%
nArg = size(varargin,2); iArg = 1;
if nArg >= iArg && ~isempty(varargin{iArg})
	filename = varargin{iArg}; else
	filename = '';
end, iArg = iArg + 1;
if nArg >= iArg && ~isempty(varargin{iArg})
	nt = varargin{iArg}; else
	nt = 60;
end, iArg = iArg + 1;
if nArg >= iArg && ~isempty(varargin{iArg})
 	yesplot = varargin{iArg}; else
 	yesplot = false;
end%, iArg = iArg + 1;

if ~ischar(filename)
	error('wrong argument type')
end



%
% Reading in the lsm files and extracting the images stacks.  We throw
% out the first z-slice because sometimes our microscope puts things
% out of order.
%
lsminf2 = lsminfo(filename);
% if ~strcmp(lsminf2.ScanInfo.ENTRY_OBJECTIVE,...
% 		'Plan-Neofluar 40x/1.3 Oil DI')
if isempty(strfind(lsminf2.ScanInfo.ENTRY_OBJECTIVE,'40x'))
	error('Wrong objective')
end % break out if we don't have our 40x objective

%
% Defining what is in each channel.  Here we assume "Dorsal" is in the 488
% channel, histones (or nuclei) are in the 555 channel, and rna in the 647
% channel.
%
filters = lsminf2.ScanInfo.FILTER_NAME;
dc = strmatch('BP 505-53',filters);
hc = strmatch('LP 56',filters);
rc = strmatch('LP 65',filters);


lsm =  lsmReadDU(filename);
lsminf1 = lsm.lsm;
scalings = 1e6*[lsminf1.VoxelSizeX,lsminf1.VoxelSizeY,...
	lsminf1.VoxelSizeZ]; % microns/pixel
rho = round(scalings(3)/scalings(1)); % hope we don't have to round much.


numch = lsminf1.DimensionChannels;
IM = lsm.data(:,:,:,2:end);
clear lsm

if lsminf2.ScanInfo.USE_ROIS&&~lsminf2.ScanInfo.USE_REDUCED_MEMORY_ROIS
	
	%
	% Extracting our region of interest.  There will be a rectangle
	% that contains the embryo, outside of which all pixels will be
	% zero.
	%
	I = sum(squeeze(IM(:,:,hc,:)),3) + sum(squeeze(IM(:,:,dc,:)),3);
	maxbw = logical(max(I)); j = find(maxbw); j1 = j(1); j2 =j(end);
	bwj = logical(I(:,j1)); i = find(bwj); i1 = i(1); i2 = i(end);
	
	IM = IM(i1:i2,j1:j2,:,:);
end

%
% Subtracting background.
%
bg = zeros(numch,1);
bgsig = zeros(numch,1);
for i = 1:numch
	secondslice = double(IM(:,:,i,2));
% 	[bg(i),A] = mode(secondslice(:));
	[n,x] = hist(secondslice(:),0:4095);
	[A,k] = max(n);
	bg(i) = x(k);
	X = x(max(k-4,1):k+4);
	Y = n(max(k-4,1):k+4);
	SIG = (X-bg(i))./sqrt(-2*log(Y/A));
	bgsig(i) = sqrt(meanDU(SIG'.^2));
	IM(:,:,i,:) = imsubtract(IM(:,:,i,:),bg(i));
end

D = lsminf1.DimensionZ-1; % depth
[H,W] = size(squeeze(IM(:,:,1,1))); % height, width
Yhatmax = round(18.36/scalings(1)); % This is the width of the ring 
% (radius_outer - radius_inner) in pixels.  This width is 18.36 microns.

%
% Middle remarks:
%
data.filename = filename;
data.genotype = '';
data.genename = '';
data.lsminf1 = lsminf1;
data.lsminf2 = lsminf2;
data.scalings = scalings;
data.rho = rho;
data.Yhatmax = Yhatmax;
data.nt = nt;
data.nuc_ch = hc;
data.dl_ch = dc;
data.rna_ch = rc;
data.bg = bg;
data.std_bg = bgsig;
data.H = H; 
data.W = W; 
data.D = D;

%
% First we find the inner and outer borders around the embryo.  Then we use
% these borders to unroll the embryo.
%
th = linspace(-pi,pi,nt+1)';
nt2 = 300;
theta = linspace(-pi,pi,nt2+1)';
s2 = linspace(-1,1,nt2+1)';
h = 0.25;
arc = zeros(D,1);
T = cell(D,1);
mrna = zeros(D,nt2+1); smrna = mrna;
Xp = cell(D,1); Yp = Xp; 
X1 = Xp; Y1 = Xp; S = Xp;
Dorsal = Xp; Nuc = Xp; Ratio = Xp;
Std_dl = Xp; Std_nuc = Xp; Std_ratio = Xp;
U = Xp; BW = Xp;
for i = 1:D
	I = IM(:,:,:,i);
	
	%
	% border and perimiter.
	%
	[xp,yp] = borderFinder(I,h,yesplot,nt);
	Xp{i} = xp; Yp{i} = yp;
	% 	[g,Rp(:,i)] = cart2pol(xp-xc,yp-yc);
	arc(i) = sum(sqrt(diff(xp).^2 + diff(yp).^2));
	
% 	%
% 	% Diagnostic to output images to see if the periphery is right.  But it
% 	% takes three times as long to run the code with this diagnostic.
% 	%
% 	fh = figure('visible','off');
% 	imagesc(sum(double(I),3));
% 	hold on
% 	axis equal
% 	plot(xp,yp,'w')
% 	k = strfind(filename,filesep);
% 	if isempty(k), k = 0; end
% 	filenameshort = filename(k(end)+1:end-4);
% 	print(fh,'-djpeg','-r150',...
% 		['.',filesep,'Peripheryimages',filesep,...
% 		filenameshort,'_',num2strDU(i,3),'.jpg'])
	
	%
	% Segmenting in on an unrolled strip, then returning the data to the
	% annulus ring in a bw image, "nucmask".
	%
	[dorsal,nuc,xnuc,ynuc,snuc,std_dl,std_nuc,u,bw,im] = ...
		find_nucleiDU(data,I(:,:,[dc,hc]),xp,yp,Yhatmax,yesplot);
	X1{i} = xnuc;
	Y1{i} = ynuc;
	S{i} = 2*snuc/arc(i) - 1;
	Dorsal{i} = dorsal;
	Nuc{i} = nuc;
	Ratio{i} = dorsal./nuc*median(nuc);
	
	std_dl = sqrt(std_dl.^2 + bgsig(dc).^2);
	std_nuc = sqrt(std_nuc.^2 + bgsig(hc).^2);
	Std_dl{i} = std_dl;
	Std_nuc{i} = std_nuc;
	Std_ratio{i} = Ratio{i}.*sqrt((std_dl./dorsal).^2 + (std_nuc./nuc).^2);
	U{i} = u;
	BW{i} = bw;
	
% 	%
% 	% Diagnostic to output images to see if the segmentation is right.  But it
% 	% longer to run the code with this diagnostic.
% 	%
% 	k = strfind(filename,filesep);
% 	if isempty(k), k = 0; end
% 	filenameshort = filename(k(end)+1:end-4);
% 	imwrite(im,['.',filesep,'Segmentationimages',filesep,...
% 	filenameshort,'_',num2strDU(i,3),'.jpg'],'jpg')
	
	%
	% Measuring the rna conc around the outside of the embryo.
	%
	[t,s] = domainMeas(I(:,:,[rc,hc]),xp,yp);%,Yhatmax,nt2);
	T{i} = t;
	rna = t(:,1)./t(:,2);
% 	dx = diff(xp); dy = diff(yp); ds = sqrt(dx.^2 + dy.^2);
% 	s = [0;cumsum(ds)];
% 	s = interp1(th,s,theta);
% 	rna = interp1(2*s/sum(ds)-1,rna,s2);
	mrna(i,:) = rna';
	p = round(nt2/20);
	rna = [rna(end-p+1:end);rna;rna(1:p)];
	srna = smooth(rna,p);
	smrna(i,:) = srna(p+1:end-p);
end
w = mean(arc);

BW2 = BW;
U2 = U;
U = zeros(Yhatmax,round(w),D);
BW = false(Yhatmax,round(w),D);
for i = 1:D
	U(:,:,i) = imresize(U2{i},[Yhatmax,round(w)]);
	BW(:,:,i) = imresize(BW2{i},[Yhatmax,round(w)]);
end
save U U BW filename

data.w = w;
data.arc = arc;
data.L = arc/2*scalings(1);
data.Lbar = w/2*scalings(1);
data.Xp = Xp;
data.Yp = Yp;
data.X = X1;
data.Y = Y1;
data.S = S;
data.Dorsal = Dorsal;
data.Std_dl = Std_dl;
data.Nuc = Nuc;
data.Std_nuc = Std_nuc;
data.Ratio = Ratio;
data.Std_ratio = Std_ratio;
data.s2 = s2;
data.mrna = mrna;
data.smrna = smrna;
data.Raw = T;
save([data.filename(1:end-4),'_data.mat'],'data');
save([data.filename(1:end-4),'_U.mat'],'U','BW');
