function varargout = c1628(I16,fh)
% takes an RGB uint16 and transforms it into uint8.
%
% function I8 = c1628(I16,fh)
%
% if no output is asked for, none is given, and you get an imshow instead.
%
% This function also works if "I16" is a double (ie, not just uint16).
%
% "fh" is a figure handle, if you want to send your plot to a particular
%	figure.  If this isn't specified, and no output is asked for, then
%	this function will just say "figure" rather than "figure(fh)".

I = double(I16);
clear I16

Imax = max(I(:));
Imin = min(I(:));

I = 255*(I - Imin)/(Imax - Imin);
I8 = uint8(I);

if nargout == 0
	if exist('fh','var') && round(fh) == fh
		figure(fh)
	else
		figure
	end
	if size(I8,3) == 2
		Z = zeros(size(I8,1),size(I8,2));
		I8(:,:,3) = Z;
	end
	imshow(I8,[])
else
	varargout = {I8};
end